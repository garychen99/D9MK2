const short temptable_147[][2] PROGMEM = {
  PtLine(  0, 100, 4700)
  PtLine( 50, 100, 4700)
  PtLine(100, 100, 4700)
  PtLine(150, 100, 4700)
  PtLine(200, 100, 4700)
  PtLine(250, 100, 4700)
  PtLine(300, 100, 4700)
};
