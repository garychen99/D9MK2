const short temptable_110[][2] PROGMEM = {
  PtLine(  0, 100, 1000)
  PtLine( 50, 100, 1000)
  PtLine(100, 100, 1000)
  PtLine(150, 100, 1000)
  PtLine(200, 100, 1000)
  PtLine(250, 100, 1000)
  PtLine(300, 100, 1000)
};
