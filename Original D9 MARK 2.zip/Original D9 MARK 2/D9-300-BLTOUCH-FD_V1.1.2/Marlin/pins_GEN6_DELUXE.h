#define BOARD_NAME "Gen6 Deluxe"
#include "pins_GEN6.h"
