#ifndef BOARD_NAME
  #define BOARD_NAME "RAMPS 1.3"
#endif
#define IS_RAMPS_13
#include "pins_RAMPS.h"
