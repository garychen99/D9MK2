#ifndef __PCA9632_H__
#define __PCA9632_H__
#include "Arduino.h"
#include "Wire.h"
void PCA9632_SetColor(const byte r, const byte g, const byte  b);
#endif 
