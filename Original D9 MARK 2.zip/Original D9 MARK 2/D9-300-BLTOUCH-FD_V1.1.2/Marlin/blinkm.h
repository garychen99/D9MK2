#include "Arduino.h"
#include "Wire.h"
void SendColors(byte red, byte grn, byte blu);
